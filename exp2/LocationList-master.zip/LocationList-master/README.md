# 和风天气常用地区列表 

和风天气提供全球15万个城市和地区的天气数据服务，使用城市列表中的Location ID获取天气数据。

- 请使用[城市查询接口](https://dev.qweather.com/docs/api/geo)获取更多城市信息，或保持城市数据更新。
- 本文档不定期更新。

# QWeather Location List

We provides weather data service for 150,000 cities around the world, get the weather data using the Location ID in these lists.

- Please use the [Geo Lookup API](https://dev.qweather.com/docs/api/geo) to get all location information and keep the them up to date.
- This list will be updated as needed.